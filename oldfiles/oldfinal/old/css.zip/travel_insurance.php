<?php include ("header.php")?>
<div class="inner-banner style-6">
	<img class="center-image" src="img/bg_1.jpg" alt="">
	<div class="vertical-align">
		<div class="container">
			<div class="row">
				<div class="col-xs-12 col-md-8 col-md-offset-2">
		  			
		  			<h2 class="color-white">Travel Insurance</h2>
  				</div>
			</div>
		</div>
	</div>
</div>

<!-- BLOG -->
<div class="detail-wrapper">
	<div class="container">
       	<div class="row padd-90">
       		<div class="col-xs-12 col-sm-12 col-md-10 col-md-offset-1">
       			<div class="blog-list">
					<div class="blog-list-entry style-2">
						<div class="blog-list-text color-grey-3">
						We do provide travel insurance along with all flight tickets.
						</br></br>
						<table width="100%" border="1" cellspacing="5" cellpadding="5" style="border: 1px solid black">
  <tr style="background-color:#000; color:#fff;">
    <td>Trip Cost</td>
    <td>Insurance Cost</td>
  </tr>
  <tr>
    <td>$0 - $99.99 </td>
    <td>$7.99 </td>
  </tr>
  <tr>
    <td>$100 - $199.99 </td>
    <td>$12.99 </td>
  </tr>
  <tr>
    <td>$200 - $499.99 </td>
    <td>TripPrice/100 * 5.50 </td>
  </tr>
  <tr>
    <td>$500 - $999.99 </td>
    <td>TripPrice/100 * 6.000 </td>
  </tr>
  <tr>
    <td>$1000 - $100001  </td>
    <td>TripPrice/100 * 6.75 </td>
  </tr>
</table>
</br>
						
Reasons of covering - Sickness, injury or death of a traveler, traveling companion or immediate family member; or other covered events such as cancellation of arrangements by an airline due to strike or bad weather; jury duty; involvement in documented traffic accident on the way to the airport; destruction of residence by a natural disaster (i.e. fire, earthquake, flood, tornado or hurricane); documented theft of passport or visas; transfer of employment of 250 miles or more 
</div>
							  	 					
					</div> 
					
				</div>				       			
       		</div>
       	</div>
	</div>
</div>

<!-- FOOTER -->      
<?php include ("footer.php")?> 
		   