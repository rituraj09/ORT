<div class="swiper-container main-slider-4" data-autoplay="1" data-loop="1" data-speed="5000" data-center="0" data-slides-per-view="1">
				<div class="swiper-wrapper">
					<div class="swiper-slide active" data-val="0">
						<div class="hover-blue black-hover h_100">
						  	<div class="clip">
							 	<div class="bg bg-bg-chrome act" style="background-image:url(img/slide_1.jpg)"></div>
						  	</div>
						  	<div class="tour-layer delay-1"></div>
						  	
														
						</div>
				    </div> 
					<div class="swiper-slide" data-val="1">
						<div class="hover-blue black-hover h_100">
						  	<div class="clip">
							 	<div class="bg bg-bg-chrome act" style="background-image:url(img/slide_1.jpg)"></div>
						  	</div>
						  	<div class="tour-layer delay-1"></div>						  	
						  						  	
														
						</div>
				     </div>
					<div class="swiper-slide" data-val="2">
						<div class="hover-blue black-hover h_100">
							<div class="clip">
								<div class="bg bg-bg-chrome act" style="background-image:url(img/slide_1.jpg)"></div>
							</div>
						  	<div class="tour-layer delay-1"></div>							
						  						  
														
						</div>
				    </div>
					<div class="swiper-slide active" data-val="3">
						<div class="hover-blue black-hover h_100">
						  	<div class="clip">
							 	<div class="bg bg-bg-chrome act" style="background-image:url(img/slide_1.jpg)"></div>
					 	 	</div>
						  	<div class="tour-layer delay-1"></div>					 	 	
						  					 	 	
														
						</div>
				    </div>
					<div class="swiper-slide active" data-val="4">
						<div class="hover-blue black-hover h_100">
						  	<div class="clip">
							 	<div class="bg bg-bg-chrome act" style="background-image:url(img/slide_1.jpg)"></div>
						  	</div>
						  	<div class="tour-layer delay-1"></div>						  	
						  						  	
														
						</div>
				    </div>
			   </div>
				<div class="pagination poin-style-1"></div>			   		  	
	      	</div>