<?php include ("header.php");?>
<!-- INNER-BANNER -->
<div class="inner-banner style-6">
	<img class="center-image" src="img/bg_2.jpg" alt="">
	<div class="vertical-align">
		<div class="container">
			<div class="row">
				<div class="col-xs-12 col-md-8 col-md-offset-2">
		  			
		  			<h2 class="color-white">Hotel Booking</h2>
  				</div>
			</div>
		</div>
	</div>
</div>

<!-- DETAIL WRAPPER -->
<div class="detail-wrapper">
	<div class="container">
		
       	<div class="may-interested padd-90">
	       	<div class="row">
	       		<div class="col-mob-12 col-xs-6 col-sm-6 col-md-3">
		          <div class="hotel-item">
		          	 <div class="radius-top">
		          	 	 <img src="img/pop_hotel_1.jpg" alt="">
		          	 	   <div class="price price-s-1">$273</div>
		          	 </div>
		          	 <div class="title clearfix">
		          	     <h4><b>royal Hotel</b></h4>
	          	           <div class="rate-wrap">
		          	          <div class="rate">
								<span class="fa fa-star color-yellow"></span>
								<span class="fa fa-star color-yellow"></span>
								<span class="fa fa-star color-yellow"></span>
								<span class="fa fa-star color-yellow"></span>
								<span class="fa fa-star color-yellow"></span>
							  </div>
						      <i>485 rewies</i> 
	                       </div>  
		             <span class="f-14 color-dark-2">2 Place de la Sans Défense, Puteaux</span>
		             <p class="f-14">Nunc cursus libero purus ac congue arcu cursus ut sed vitae pulvinar massa idporta nequetiam.</p>
		             
		             </div>
		          </div>      			
	       		</div>
	       		<div class="col-mob-12 col-xs-6 col-sm-6 col-md-3">
			          <div class="hotel-item">
			          	 <div class="radius-top">
			          	 	 <img src="img/pop_hotel_2.jpg" alt="">
			          	 	   <div class="price price-s-1">$273</div>
			          	 </div>
			          	 <div class="title clearfix">
			          	     <h4><b>sheraton Hotel</b></h4>
		          	           <div class="rate-wrap">
			          	          <div class="rate">
									<span class="fa fa-star color-yellow"></span>
									<span class="fa fa-star color-yellow"></span>
									<span class="fa fa-star color-yellow"></span>
									<span class="fa fa-star color-yellow"></span>
									<span class="fa fa-star color-yellow"></span>
								  </div>
							      <i>485 rewies</i> 
		                       </div>  
			             <span class="f-14 color-dark-2">2 Place de la Sans Défense, Puteaux</span>
			             <p class="f-14">Nunc cursus libero purus ac congue arcu cursus ut sed vitae pulvinar massa idporta nequetiam.</p>
			             
			             </div>
			          </div>      			
	       		</div>
	       		<div class="col-mob-12 col-xs-6 col-sm-6 col-md-3">
			          <div class="hotel-item">
			          	 <div class="radius-top">
			          	 	 <img src="img/pop_hotel_3.jpg" alt="">
			          	 	   <div class="price price-s-1">$273</div>
			          	 </div>
			          	 <div class="title clearfix">
			          	     <h4><b>royal Hotel</b></h4>
		          	           <div class="rate-wrap">
			          	          <div class="rate">
									<span class="fa fa-star color-yellow"></span>
									<span class="fa fa-star color-yellow"></span>
									<span class="fa fa-star color-yellow"></span>
									<span class="fa fa-star color-yellow"></span>
									<span class="fa fa-star color-yellow"></span>
								  </div>
							      <i>485 rewies</i> 
		                       </div>  
			             <span class="f-14 color-dark-2">2 Place de la Sans Défense, Puteaux</span>
			             <p class="f-14">Nunc cursus libero purus ac congue arcu cursus ut sed vitae pulvinar massa idporta nequetiam.</p>
			             
			             </div>
			          </div>       			
	       		</div>
	       		<div class="col-mob-12 col-xs-6 col-sm-6 col-md-3">
			          <div class="hotel-item">
			          	 <div class="radius-top">
			          	 	 <img src="img/pop_hotel_4.jpg" alt="">
			          	 	   <div class="price price-s-1">$273</div>
			          	 </div>
			          	 <div class="title clearfix">
			          	     <h4><b>sheraton Hotel</b></h4>
		          	           <div class="rate-wrap">
			          	          <div class="rate">
									<span class="fa fa-star color-yellow"></span>
									<span class="fa fa-star color-yellow"></span>
									<span class="fa fa-star color-yellow"></span>
									<span class="fa fa-star color-yellow"></span>
									<span class="fa fa-star color-yellow"></span>
								  </div>
							      <i>485 rewies</i> 
		                       </div>  
			             <span class="f-14 color-dark-2">2 Place de la Sans Défense, Puteaux</span>
			             <p class="f-14">Nunc cursus libero purus ac congue arcu cursus ut sed vitae pulvinar massa idporta nequetiam.</p>
			             
			             </div>
			          </div>     			
	       		</div>  
                <div class="col-mob-12 col-xs-6 col-sm-6 col-md-3">
			          <div class="hotel-item">
			          	 <div class="radius-top">
			          	 	 <img src="img/pop_hotel_4.jpg" alt="">
			          	 	   <div class="price price-s-1">$273</div>
			          	 </div>
			          	 <div class="title clearfix">
			          	     <h4><b>sheraton Hotel</b></h4>
		          	           <div class="rate-wrap">
			          	          <div class="rate">
									<span class="fa fa-star color-yellow"></span>
									<span class="fa fa-star color-yellow"></span>
									<span class="fa fa-star color-yellow"></span>
									<span class="fa fa-star color-yellow"></span>
									<span class="fa fa-star color-yellow"></span>
								  </div>
							      <i>485 rewies</i> 
		                       </div>  
			             <span class="f-14 color-dark-2">2 Place de la Sans Défense, Puteaux</span>
			             <p class="f-14">Nunc cursus libero purus ac congue arcu cursus ut sed vitae pulvinar massa idporta nequetiam.</p>
			             
			             </div>
			          </div>     			
	       		</div>
                <div class="col-mob-12 col-xs-6 col-sm-6 col-md-3">
			          <div class="hotel-item">
			          	 <div class="radius-top">
			          	 	 <img src="img/pop_hotel_4.jpg" alt="">
			          	 	   <div class="price price-s-1">$273</div>
			          	 </div>
			          	 <div class="title clearfix">
			          	     <h4><b>sheraton Hotel</b></h4>
		          	           <div class="rate-wrap">
			          	          <div class="rate">
									<span class="fa fa-star color-yellow"></span>
									<span class="fa fa-star color-yellow"></span>
									<span class="fa fa-star color-yellow"></span>
									<span class="fa fa-star color-yellow"></span>
									<span class="fa fa-star color-yellow"></span>
								  </div>
							      <i>485 rewies</i> 
		                       </div>  
			             <span class="f-14 color-dark-2">2 Place de la Sans Défense, Puteaux</span>
			             <p class="f-14">Nunc cursus libero purus ac congue arcu cursus ut sed vitae pulvinar massa idporta nequetiam.</p>
			             
			             </div>
			          </div>     			
	       		</div>      		       		       		
	       	</div>
       	</div>
	</div>
</div>
<?php include ("footer.php");?>		   