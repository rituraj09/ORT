<?php include ("header.php")?>
<div class="inner-banner style-6">
	<img class="center-image" src="img/disclaimer_bg.jpg" alt="">
	<div class="vertical-align">
		<div class="container">
			<div class="row">
				<div class="col-xs-12 col-md-8 col-md-offset-2">
		  			
		  			<h2 class="color-white">Disclaimer</h2>
  				</div>
			</div>
		</div>
	</div>
</div>

<!-- BLOG -->
<div class="detail-wrapper">
	<div class="container">
       	<div class="row padd-90">
       		<div class="col-xs-12 col-sm-12 col-md-10 col-md-offset-1">
       			<div class="blog-list">
					<div class="blog-list-entry style-2">
					<div class="blog-list-text color-grey-3">
					Information included herein is intended only for customers or travelers using our website and services. The flight rates and hotel rates keep changing and fluctuating and we heavily rely on service providers for the accuracy of rates. Largely, every effort is made to keep the information provided correct, clear and concise. However, we cannot be held responsible for damages or inconvenience caused due to services from a third party which may be an airline or a hotel. <br>
<br>

We expressly disclaim all liabilities that may arise while availing our services. We suggest our customers to get in touch with the airlines in case of a delay or cancellation due to unforeseen circumstances, including natural calamity or in state of emergency.<br>
<br>

Although we have provided links to other website to deliver services, we are not responsible for inaccuracy of contents, which may not be suitable to certain age group, class or race, on these sites. Though we take a due care to keep all and any information accurate and unambiguous, we are not liable for any damages arising out of such information. Please use your discretion while engaging in our services and services of a third party.
</div>
							  	 					
					</div> 
					
				</div>				       			
       		</div>
       	</div>
	</div>
</div>

<!-- FOOTER -->      
<?php include ("footer.php")?> 
		   