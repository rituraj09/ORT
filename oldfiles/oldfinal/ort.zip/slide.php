	<div class="full-height">
     <div class="clip">
		<div class="bg bg-bg-chrome" style="background-image:url(img/slider.jpg)">
       
		</div>
	 </div>
	 <div class="vertical-align">
	  <div class="container">
	  	<div class="tabs-slider">
	  	   <div class="baner-tabs">
			   <div class="text-center">
				 <div class="drop-tabs">
				   <b>Flights</b>	
					<a href="#" class="arrow-down"><i class="fa fa-angle-down"></i></a>
					 <ul class="nav-tabs tpl-tabs tabs-style-1">
						<li class="active click-tabs"><a href="#one" data-toggle="tab" aria-expanded="false"><span class="fa fa-plane"></span>flights</a>  </li>
						<!--<li class="click-tabs"><a href="#two" data-toggle="tab" aria-expanded="false"><span class="fa fa-bed"></span>hotels</a></li>
						<li class="click-tabs"><a href="#three" data-toggle="tab" aria-expanded="false"><span class="fa fa-car"></span>cars</a></li>-->
						
					 </ul>
				 </div>
			   </div>
	           <div class="tab-content tpl-tabs-cont section-text t-con-style-1">
				<div class="tab-pane active in" id="one">
                  <div class="timePiker"></div>
                   <div class="baner-bar cars-bar">
					<?php include ("form.php")?>
				 </div>
				</div>
                <div class="tab-pane" id="two">
				   <form action="#" class="hotel-filter">
					<div class="baner-bar">
					  <div class="row">
						<div class="col-md-4">
						 <div class="hotels-block">
						  <h4>where</h4>
							<div class="input-style-1">
								<img src="img/loc_icon_small_grey.png" alt="">
								  <input type="text" placeholder="Enter a destination or hotel name" required>
							</div>
						 </div>	
						</div>
						<div class="col-md-2">
						  <div class="hotels-block">
						   <h4>Check in</h4>
							<div class="input-style-1">
								<img src="img/calendar_icon_grey.png" alt="">
								  <input type="text" placeholder="" class="datepicker" required>
							</div>
						  </div>
						</div>
						<div class="col-md-2">
						  <div class="hotels-block">
						   <h4>Check in</h4>
							<div class="input-style-1">
								<img src="img/calendar_icon_grey.png" alt="">
								  <input type="text" placeholder="" class="datepicker" required>
							</div>
						  </div>
						</div>
						<div class="col-md-2">
						  <div class="hotels-block">
						   <h4>rooms</h4>
						   <div class="count">
							  <a href="#" class="active">1</a>
							  <a href="#">2</a>
							  <a href="#">3</a>
							  <a href="#">3+</a>
						   </div>
						  </div>
						</div>
						<div class="col-md-2">
						  <div class="hotels-block">
						   <h4>Adult</h4>
						   <div class="count">
							  <a href="#" class="active">1</a>
							  <a href="#">2</a>
							  <a href="#">3</a>
							  <a href="#">3+</a>
						   </div>
						  </div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-8">	
							<div class="range-wrapp">
							  <h4>Price range</h4>
								<div class="slider-range" data-counter="$" data-position="start" data-from="0" data-to="5000" data-min="0" data-max="5000">
									<div class="range"></div>
									<input type="text" class="amount-start" readonly value="$0">
									<input type="text" class="amount-end" readonly value="$1500">						
								</div>
							</div>
						</div>	
						<div class="col-md-4">
							<div class="submit">
							   <input class="c-button b-60 bg-white hv-orange" type="submit" value="search now">
							</div>
						</div>
					</div>
				   </div>
				  </form>
			    </div>
		        
			    <div class="tab-pane" id="three">
			      <div class="timePiker"></div>
				   <div class="baner-bar cars-bar">
					<div class="row">
						<div class="col-md-12">
						 <div class="hotels-block">
						  <h4>From</h4>
							<div class="input-style-1">
								<img src="img/loc_icon_small_grey.png" alt="">
								  <input type="text" placeholder="Destination; Zip Code" required>
							</div>
							<div class="input-entry color-5">
								<input class="checkbox-form" id="text-2" type="checkbox" name="checkbox" value="climat control">
								<label class="clearfix" for="text-2">
									<span class="sp-check"><i class="fa fa-check"></i></span>
									<span class="checkbox-text">Same location</span>
								</label>
							</div>
						 </div>	
						</div>
					</div>
					<div class="row">
						<div class="col-md-12">
						 <div class="hotels-block">
						  <h4>To</h4>
							<div class="input-style-1">
								<img src="img/loc_icon_small_grey.png" alt="">
								  <input type="text" placeholder="Destination; Zip Code" required>
							</div>
						 </div>	
						</div>
					</div>
					<div class="row">
						<div class="col-md-2">
						  <div class="hotels-block">
						   <h4>Check in</h4>
							<div class="input-style-1">
								<img src="img/calendar_icon_grey.png" alt="">
								  <input type="text" placeholder="" class="datepicker" required>
							</div>
						  </div>
						</div>
						<div class="col-md-2">
						  <div class="hotels-block">
						   <h4>Time</h4>
							<div class="time-input">
							  <img src="img/clock.png" alt="">
								<input type="text" data-field="time" readonly>
							</div>
						  </div>
						</div>
						<div class="col-md-2">
						  <div class="hotels-block">
						   <h4>Check in</h4>
							<div class="input-style-1">
								<img src="img/calendar_icon_grey.png" alt="">
								  <input type="text" placeholder="" class="datepicker" required>
							</div>
						  </div>
						</div>
						<div class="col-md-2">
						  <div class="hotels-block">
						   <h4>Time</h4>
							<div class="time-input">
							  <img src="img/clock.png" alt="">
								<input type="text" data-field="time" readonly>
							</div>
						  </div>

						</div>
						<div class="col-md-2 col-md-offset-2">
							<div class="submit">
							   <input class="c-button b-60 bg-white hv-orange" type="submit" value="search now">
							</div>
						</div>
					</div>

					<div class="row">
						<div class="col-md-12">	
							<div class="range-wrapp">
							   <h4>Price range</h4>
								<div class="slider-range" data-counter="$" data-position="start" data-from="0" data-to="5000" data-min="0" data-max="5000">
									<div class="range"></div>
									<input type="text" class="amount-start" readonly value="$0">
									<input type="text" class="amount-end" readonly value="$1500">						
								</div>
							</div>
						</div>	
					</div>
				 </div>
			</div>			
				<div class="tab-pane" id="four">
                  <div class="timePiker"></div>
                   <div class="baner-bar cars-bar">
					<div class="row">
						<div class="col-md-12">
						 <div class="hotels-block">
						  <h4>From</h4>
							<div class="input-style-1">
								<img src="img/loc_icon_small_grey.png" alt="">
								  <input type="text" placeholder="Destination; Zip Code" required>
							</div>
							<div class="input-entry color-5">
								<input class="checkbox-form" id="text-3" type="checkbox" name="checkbox" value="climat control">
								<label class="clearfix" for="text-3">
									<span class="sp-check"><i class="fa fa-check"></i></span>
									<span class="checkbox-text">Same location</span>
								</label>
							</div>
						 </div>	
						</div>
					</div>
					<div class="row">
						<div class="col-md-12">
						 <div class="hotels-block">
						  <h4>To</h4>
							<div class="input-style-1">
								<img src="img/loc_icon_small_grey.png" alt="">
								  <input type="text" placeholder="Destination; Zip Code" required>
							</div>
						 </div>	
						</div>
					</div>
					<div class="row">
						<div class="col-md-2">
						  <div class="hotels-block">
						   <h4>Check in</h4>
							<div class="input-style-1">
								<img src="img/calendar_icon_grey.png" alt="">
								  <input type="text" placeholder="" class="datepicker" required>
							</div>
						  </div>
						</div>
						<div class="col-md-2">
						  <div class="hotels-block">
						   <h4>Time</h4>
							<div class="time-input">
							  <img src="img/clock.png" alt="">
								<input type="text" data-field="time" readonly>
							</div>
						  </div>
						</div>
						<div class="col-md-2">
						  <div class="hotels-block">
						   <h4>Check in</h4>
							<div class="input-style-1">
								<img src="img/calendar_icon_grey.png" alt="">
								  <input type="text" placeholder="" class="datepicker" required>
							</div>
						  </div>
						</div>
						<div class="col-md-2">
						  <div class="hotels-block">
						   <h4>Time</h4>
							<div class="time-input">
							  <img src="img/clock.png" alt="">
								<input type="text" data-field="time" readonly>
							</div>
						  </div>

						</div>
						<div class="col-md-2 col-md-offset-2">
							<div class="submit">
							   <input class="c-button b-60 bg-white hv-orange" type="submit" value="search now">
							</div>
						</div>
					</div>

					<div class="row">
						<div class="col-md-12">	
							<div class="range-wrapp">
							   <h4>Price range</h4>
								<div class="slider-range" data-counter="$" data-position="start" data-from="0" data-to="5000" data-min="0" data-max="5000">
									<div class="range"></div>
									<input type="text" class="amount-start" readonly value="$0">
									<input type="text" class="amount-end" readonly value="$1500">						
								</div>
							</div>
						</div>	
					</div>
				 </div>
				</div>
				<div class="tab-pane" id="five">
                    <form action="#" class="hotel-filter">
					   <div class="baner-bar">
						  <div class="row">
							<div class="col-md-4">
							 <div class="hotels-block">
							  <h4>where</h4>
								<div class="input-style-1">
									<img src="img/loc_icon_small_grey.png" alt="">
									  <input type="text" placeholder="Destination; Zip Code" required>
								</div>
							 </div>	
							</div>
							<div class="col-md-2">
							  <div class="hotels-block">
							   <h4>Check in</h4>
								<div class="input-style-1">
									<img src="img/calendar_icon_grey.png" alt="">
									  <input type="text" placeholder="" class="datepicker" required>
								</div>
							  </div>
							</div>
							<div class="col-md-2">
							  <div class="hotels-block">
							   <h4>Check in</h4>
								<div class="input-style-1">
									<img src="img/calendar_icon_grey.png" alt="">
									  <input type="text" placeholder="" class="datepicker" required>
								</div>
							  </div>
							</div>
							<div class="col-md-2">
							  <div class="hotels-block">
							   <h4>rooms</h4>
							   <div class="count">
								  <a href="#" class="active">1</a>
								  <a href="#">2</a>
								  <a href="#">3</a>
								  <a href="#">3+</a>
							   </div>
							  </div>
							</div>
							<div class="col-md-2">
							  <div class="hotels-block">
							   <h4>Adult</h4>
							   <div class="count">
								  <a href="#" class="active">1</a>
								  <a href="#">2</a>
								  <a href="#">3</a>
								  <a href="#">3+</a>
							   </div>
							  </div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-8">	
								<div class="range-wrapp">
								  <h4>Price range</h4>
									<div class="slider-range" data-counter="$" data-position="start" data-from="0" data-to="5000" data-min="0" data-max="5000">
										<div class="range"></div>
										<input type="text" class="amount-start" readonly value="$0">
										<input type="text" class="amount-end" readonly value="$1500">						
									</div>
								</div>
							</div>	
							<div class="col-md-4">
								<div class="submit">
								   <input class="c-button b-60 bg-white hv-orange" type="submit" value="search now">
								</div>
							</div>
						</div>
					 </div>
				   </form>
				</div>
	         </div>
	       </div>
	    </div>
	  </div>
   </div>
  </div>

