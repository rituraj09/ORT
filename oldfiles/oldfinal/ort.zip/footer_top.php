<div class="main-wraper">
	<div class="container">
		
		<div class="row">
			<div class="col-xs-12 col-sm-6 col-md-3">
				<div class="icon-block">
					<img class="icon-img" src="img/call.png" alt="">
					<h5 class="icon-title color-dark-2">Call Us</h5>
					
				</div>
			</div>
			<div class="col-xs-12 col-sm-6 col-md-3">
				<div class="icon-block">
					<img class="icon-img" src="img/email.png" alt="">
					<h5 class="icon-title color-dark-2">Email Us</h5>
					
				</div>
			</div>
			<div class="col-xs-12 col-sm-6 col-md-3">
				<div class="icon-block">
					<img class="icon-img" src="img/chat.png" alt="">
					<h5 class="icon-title color-dark-2">Live Chat</h5>
					
				</div>
			</div>
												
		</div>
	</div>
</div>