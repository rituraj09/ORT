<form>
                    <div class="row">
						<div class="col-md-12">
						 <div class="hotels-block">
						  <h4>Flight Booking</h4>
                          
							<div class="input-style-1">
                            <!--<input name="trip" type="radio" value="One Way">One Way
                                <input name="trip" type="radio" value="Round WayS">Round Way-->
                                
								
								  <input type="text" placeholder="Leaving From" required>
								  
                                  <input type="text" placeholder="Leaving To" required>
							</div>
							<div class="input-style-1">
                            
								  <input type="text" placeholder="Departure Date" required>
								  
                                  <input type="text" placeholder="Return Date" required>
							</div>
							<div class="input-style-1" >
<table width="100%" border="0">
  <tr>
    <td>Adults:</td>
    <td>Child:</td>
    <td>Class:</td>
	<td></td>
  </tr>
  <tr>
    <td><select name="adult">
                            <option value="0">-Select-</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
							<option value="3">3</option>
                            <option value="4">4</option>
							<option value="5">5</option>
                            <option value="6">6</option>
							<option value="7">7</option>
                            <option value="8">8</option>
                            </select></td>
    <td><select name="child">
                            <option value="0">-Select-</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
							<option value="3">3</option>
                            <option value="4">4</option>
							<option value="5">5</option>
                            <option value="6">6</option>
							<option value="7">7</option>
                            <option value="8">8</option>
                            </select></td>
                            <td><select name="Class">
                            <option value="0">-Select-</option>
                            <option value="1">First Class</option>
                            <option value="1">Premium</option>
                            <option value="1">Economy</option>
                            </select></td>
							<td> <input name="submit" type="button" value="suubmit"></td>
  </tr>
  
</table>

                            
								 
								  

                                  
							</div>
						 </div>	
						</div>
					</div>
					
					
                    </form>