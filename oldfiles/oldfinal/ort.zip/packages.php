<?php include ("header.php");?>

<!-- INNER-BANNER -->
<div class="inner-banner style-6">
	<img class="center-image" src="img/bg_6.jpg" alt="">
	<div class="vertical-align">
		<div class="container">
			<div class="row">
				<div class="col-xs-12 col-md-8 col-md-offset-2">
		  			
		  			<h2 class="color-white">Tour Packages</h2>
  				</div>
			</div>
		</div>
	</div>
</div>

<!-- TEAM -->
<div class="main-wraper padd-70-70">
	<div class="container">
		<div class="filter-content row">
			<div class="grid-sizer col-mob-12 col-xs-6 col-sm-2"></div>
			<div class="item hotels gal-item style-3 col-mob-12 col-xs-6 col-sm-4">
				<a class="black-hover" href="contact.php">
					<div class="gal-item-icon">
						<img class="img-full img-responsive" src="img/m_gal_1.jpg" alt="">
						<div class="tour-layer delay-1"></div>
						<div class="vertical-align">
							<span class="c-button small bg-white delay-2"><span>Enquire</span></span>
						</div>
					</div>
					<div class="gal-item-desc delay-1">
						<h4><b>monaco, monte carlo</b></h4>					
						<h5>sea tours</h5>
					</div>
				</a>
			</div>
			<div class="item hotels gal-item style-3 col-mob-12 col-xs-6 col-sm-4">
				<a class="black-hover" href="contact.php">
					<div class="gal-item-icon">
						<img class="img-full img-responsive" src="img/m_gal_2.jpg" alt="">
						<div class="tour-layer delay-1"></div>
						<div class="vertical-align">
							<span class="c-button small bg-white delay-2"><span>Enquire</span></span>
						</div>
					</div>
					<div class="gal-item-desc delay-1">
						<h4><b>paris, france</b></h4>					
						<h5>mountain tours</h5>
					</div>
				</a>
			</div>
			<div class="item hotels gal-item style-3 col-mob-12 col-xs-6 col-sm-4">
				<a class="black-hover" href="contact.php">
					<div class="gal-item-icon">
						<img class="img-full img-responsive" src="img/m_gal_3.jpg" alt="">
						<div class="tour-layer delay-1"></div>
						<div class="vertical-align">
							<span class="c-button small bg-white delay-2"><span>Enquire</span></span>
						</div>
					</div>
					<div class="gal-item-desc delay-1">
						<h4><b>santorini, Greece</b></h4>					
						<h5>sea tours</h5>
					</div>
				</a>
			</div>
				<div class="item hotels gal-item style-3 col-mob-12 col-xs-6 col-sm-4">
				<a class="black-hover" href="contact.php">
					<div class="gal-item-icon">
						<img class="img-full img-responsive" src="img/m_gal_1.jpg" alt="">
						<div class="tour-layer delay-1"></div>
						<div class="vertical-align">
							<span class="c-button small bg-white delay-2"><span>Enquire</span></span>
						</div>
					</div>
					<div class="gal-item-desc delay-1">
						<h4><b>monaco, monte carlo</b></h4>					
						<h5>sea tours</h5>
					</div>
				</a>
			</div>
			<div class="item hotels gal-item style-3 col-mob-12 col-xs-6 col-sm-4">
				<a class="black-hover" href="contact.php">
					<div class="gal-item-icon">
						<img class="img-full img-responsive" src="img/m_gal_2.jpg" alt="">
						<div class="tour-layer delay-1"></div>
						<div class="vertical-align">
							<span class="c-button small bg-white delay-2"><span>Enquire</span></span>
						</div>
					</div>
					<div class="gal-item-desc delay-1">
						<h4><b>paris, france</b></h4>					
						<h5>mountain tours</h5>
					</div>
				</a>
			</div>
			<div class="item hotels gal-item style-3 col-mob-12 col-xs-6 col-sm-4">
				<a class="black-hover" href="contact.php">
					<div class="gal-item-icon">
						<img class="img-full img-responsive" src="img/m_gal_3.jpg" alt="">
						<div class="tour-layer delay-1"></div>
						<div class="vertical-align">
							<span class="c-button small bg-white delay-2"><span>Enquire</span></span>
						</div>
					</div>
					<div class="gal-item-desc delay-1">
						<h4><b>santorini, Greece</b></h4>					
						<h5>sea tours</h5>
					</div>
				</a>
			</div>
            <div class="item hotels gal-item style-3 col-mob-12 col-xs-6 col-sm-4">
				<a class="black-hover" href="contact.php">
					<div class="gal-item-icon">
						<img class="img-full img-responsive" src="img/m_gal_1.jpg" alt="">
						<div class="tour-layer delay-1"></div>
						<div class="vertical-align">
							<span class="c-button small bg-white delay-2"><span>Enquire</span></span>
						</div>
					</div>
					<div class="gal-item-desc delay-1">
						<h4><b>monaco, monte carlo</b></h4>					
						<h5>sea tours</h5>
					</div>
				</a>
			</div>
			<div class="item hotels gal-item style-3 col-mob-12 col-xs-6 col-sm-4">
				<a class="black-hover" href="contact.php">
					<div class="gal-item-icon">
						<img class="img-full img-responsive" src="img/m_gal_2.jpg" alt="">
						<div class="tour-layer delay-1"></div>
						<div class="vertical-align">
							<span class="c-button small bg-white delay-2"><span>Enquire</span></span>
						</div>
					</div>
					<div class="gal-item-desc delay-1">
						<h4><b>paris, france</b></h4>					
						<h5>mountain tours</h5>
					</div>
				</a>
			</div>
			<div class="item hotels gal-item style-3 col-mob-12 col-xs-6 col-sm-4">
				<a class="black-hover" href="contact.php">
					<div class="gal-item-icon">
						<img class="img-full img-responsive" src="img/m_gal_3.jpg" alt="">
						<div class="tour-layer delay-1"></div>
						<div class="vertical-align">
							<span class="c-button small bg-white delay-2"><span>Enquire</span></span>
						</div>
					</div>
					<div class="gal-item-desc delay-1">
						<h4><b>santorini, Greece</b></h4>					
						<h5>sea tours</h5>
					</div>
				</a>
			</div>																																											
																																																			
		</div>
	</div>        		
</div>


<?php include ("footer.php");?>