<?php include ("header.php");
include ("slide.php");
?>

<!-- BLOG -->
<div class="detail-wrapper">
	<div class="container">
       	<div class="row padd-90">
       		<div class="col-xs-12 col-sm-12 col-md-10 col-md-offset-1">
       			<div class="blog-list">
					<div class="blog-list-entry style-2">
						<div class="blog-list-text color-grey-3" style="margin-top:150px;">

<strong>Want discount airline tickets? We’ll send you free alerts</strong>
<br>
<br>
Whether you’re looking for cheap airfare for a next year’s big vacation or just cheap flights for a weekend getaway, we’ll find you plenty of cheap airfare and flights to choose from. Finding cheap airlines and sales for our customers is our specialty.<br>
<br>
<strong>Get airline miles and points on flights</strong><br>
<br>
Are you a member of an airline frequent flier program? Add your account info to your One Roof Travel profile and get credit on applicable One Roof Travel flights. That’s right: Our discount airline tickets and cheap flights will also help you save in the long run. The airlines will credit your account with the points you earn. Pretty cool, huh?
Get real-time updates on flights sent to you
Stay on top of gate changes, delays on flights, and other things that come up with free One Roof Travel Care Alerts. You can have flight notifications sent by phone, email or text to up to 6 other people, too.<br>
<br>
<strong>Get all the latest news on cheap airlines sales and cheap flights</strong><br>
<br>
Find out about discount airline tickets and cheap airlines sales. Follow One Roof Travel on Facebook , Twitter, Google+ and Instagram to get exclusive cheap airfare travel coupons, promo codes and so much more.</div>
							  	 					
					</div> 
					
				</div>				       			
       		</div>
       	</div>
	</div>
</div>

<!-- FOOTER -->      
<?php include ("footer.php")?> 
		   